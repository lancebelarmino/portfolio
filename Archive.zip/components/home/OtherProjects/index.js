export { default } from './OtherProjects';
